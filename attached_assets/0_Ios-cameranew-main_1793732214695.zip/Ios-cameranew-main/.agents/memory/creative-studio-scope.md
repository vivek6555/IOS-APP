---
name: Creative studio scope
description: User-confirmed audience and architecture approval boundaries for the iOS creative studio.
---

The first release serves short-form social creators. The user selected “Compare before deciding” for native Swift versus Expo plus Swift modules; Expo selection alone is not architecture approval.

**Why:** The user explicitly answered the product-direction questions this way.

**How to apply:** Compare both routes without treating either as approved. Ask before committing to a production implementation route.

The user requires discussion of feasibility, architecture and limitations before coding. Do not generate the whole application in one attempt or present a superficial UI-only prototype as complete. Meaningful offline functionality and real editing, rendering, capture and media processing are product requirements.

**Why:** These are explicit standing constraints in the user's project brief.

**How to apply:** Keep native capability validation separate from interface previews; identify untested hardware-dependent behavior honestly.
